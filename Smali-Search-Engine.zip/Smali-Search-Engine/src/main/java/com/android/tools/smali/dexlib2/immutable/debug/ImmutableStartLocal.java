/*
 * Copyright 2012, Google LLC
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google LLC nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.android.tools.smali.dexlib2.immutable.debug;

import com.android.tools.smali.dexlib2.DebugItemType;
import com.android.tools.smali.dexlib2.base.reference.BaseStringReference;
import com.android.tools.smali.dexlib2.base.reference.BaseTypeReference;
import com.android.tools.smali.dexlib2.iface.UpdateReference;
import com.android.tools.smali.dexlib2.iface.debug.StartLocal;
import com.android.tools.smali.dexlib2.iface.reference.StringReference;
import com.android.tools.smali.dexlib2.iface.reference.TypeReference;
import com.android.tools.smali.dexlib2.writer.builder.DexBuilder;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class ImmutableStartLocal extends ImmutableDebugItem implements StartLocal, UpdateReference {
    protected final int register;
    @Nullable protected final String name;
    @Nullable protected final String type;
    @Nullable protected final String signature;

	@Nullable
    private StringReference nameRef;
    @Nullable
    private TypeReference typeRef;
    @Nullable
    private StringReference signatureRef;

    public ImmutableStartLocal(int codeAddress,
                               int register,
                               @Nullable String name,
                               @Nullable String type,
                               @Nullable String signature) {
        super(codeAddress);
        this.register = register;
        this.name = name;
        this.type = type;
        this.signature = signature;
    }

    @Nonnull
    public static ImmutableStartLocal of(@Nonnull StartLocal startLocal) {
        if (startLocal instanceof  ImmutableStartLocal) {
            return (ImmutableStartLocal)startLocal;
        }
        return new ImmutableStartLocal(
			startLocal.getCodeAddress(),
			startLocal.getRegister(),
			startLocal.getName(),
			startLocal.getType(),
			startLocal.getSignature());
    }

    @Override public int getRegister() { return register; }

    @Nullable @Override public StringReference getNameReference() {
		if (nameRef != null)
            return nameRef;
        return name == null ?null: new BaseStringReference() {
            @Nonnull @Override public String getString() {
                return name;
            }
        };
    }

    @Nullable @Override public TypeReference getTypeReference() {
		if (typeRef != null)
            return typeRef;
        return type == null ?null: new BaseTypeReference() {
            @Nonnull @Override public String getType() {
                return type;
            }
        };
    }

    @Nullable @Override public StringReference getSignatureReference() {
		if (signatureRef != null)
            return signatureRef;
        return signature == null ?null: new BaseStringReference() {
            @Nonnull @Override public String getString() {
                return signature;
            }
        };
    }

    @Nullable @Override public String getName() { return name; }
    @Nullable @Override public String getType() { return type; }
    @Nullable @Override public String getSignature() { return signature; }

    @Override public int getDebugItemType() { return DebugItemType.START_LOCAL; }

	@Override
    public void updateReference(DexBuilder dexBuilder) {
        nameRef = dexBuilder.internNullableStringReference(name);
        signatureRef = dexBuilder.internNullableStringReference(signature);
        typeRef = dexBuilder.internNullableTypeReference(type);
    }
}

