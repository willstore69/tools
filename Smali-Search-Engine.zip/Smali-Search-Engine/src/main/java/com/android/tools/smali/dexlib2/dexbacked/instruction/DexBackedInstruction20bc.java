/*
 * Copyright 2013, Google LLC
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google LLC nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.android.tools.smali.dexlib2.dexbacked.instruction;

import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.ReferenceType;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.dexbacked.reference.DexBackedReference;
import com.android.tools.smali.dexlib2.iface.UpdateReference;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction20bc;
import com.android.tools.smali.dexlib2.iface.reference.Reference;
import com.android.tools.smali.dexlib2.writer.builder.DexBuilder;
import javax.annotation.Nonnull;

public class DexBackedInstruction20bc extends DexBackedInstruction implements Instruction20bc , UpdateReference{
	private Reference reference = null;
    private int referenceType = -1;


    public DexBackedInstruction20bc(@Nonnull DexBackedDexFile dexFile,
                                    @Nonnull Opcode opcode,
                                    int instructionStart) {
        super(dexFile, opcode, instructionStart);
    }

    @Override public int getVerificationError() {
        return dexFile.getDataBuffer().readUbyte(instructionStart + 1) & 0x3f;
    }

    @Nonnull
    @Override
    public Reference getReference() {
		if (reference != null)
            return reference;

        final int referenceIndex = dexFile.getDataBuffer().readUshort(instructionStart + 2);
        try {
            int referenceType = getReferenceType();
            return DexBackedReference.makeReference(dexFile, referenceType, referenceIndex);
        } catch (final ReferenceType.InvalidReferenceTypeException ex) {
            return new Reference() {
                @Override
                public void validateReference() throws InvalidReferenceException {
                    throw new InvalidReferenceException(String.format("%d@%d", ex.getReferenceType(), referenceIndex),
														ex);
                }
            };
        }
    }

    @Override public int getReferenceType() {
		int referenceType = this.referenceType;
        if (referenceType != -1)
            return referenceType;
        referenceType = (dexFile.getDataBuffer().readUbyte(instructionStart + 1) >>> 6) + 1;
        ReferenceType.validateReferenceType(referenceType);
        return referenceType;
    }
	@Override
    public void updateReference(DexBuilder dexBuilder) {
        this.reference = dexBuilder.internReference(getReference());
    }

}

